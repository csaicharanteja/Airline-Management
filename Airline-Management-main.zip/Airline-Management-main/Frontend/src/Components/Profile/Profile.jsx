import React from 'react';
import Home from '../Home/Home';

const Profile = () => {
    return (
        <div >
            <Home/>
        </div>
    );
};

export default Profile;
